An automatic installer to set up two redundant PiHole servers.
