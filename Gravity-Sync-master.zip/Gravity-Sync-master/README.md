### This is a program to sync PiHole configurations, developed by vmstan. ###
For the original README and the documentation, [click here](https://github.com/HippoProgrammer/Gravity-Sync/blob/master/ORIGINAL_README.md)
