---
name: Bug Report
about: Help improve Gravity Sync
title: ''
labels: ''
assignees: ''

---
<!-- Unless you have identified a specifc flaw in the code or execution of the script that is repeatable, please start with a Discussion and then if asked, it can be esclated to a bug report here. Be sure to attach a screenshot of the issue, code snippts, any relevant logging. -->

**Issue Description**

**Configuration Details**
