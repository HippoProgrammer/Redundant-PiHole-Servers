---
name: Feature Request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

_Is your feature request related to a problem? If so maybe a Bug Report is more approprate? Otherwise, please give clear and concise description of what prompted your request -- Ex. "I'm always frustrated when [...]" -- then provide a clear and concise description of what you want to happen. If you're willing to commit code changes with your suggestions the project would welcome pull requests._
