/*
 * Soft:        Vrrpd is an implementation of VRRPv2 as specified in rfc2338.
 *              VRRP is a protocol which elect a master server on a LAN. If the
 *              master fails, a backup server takes over.
 *              The original implementation has been made by jerome etienne.
 *
 * Part:        Output running VRRP state information in JSON format
 *
 * Author:      Quentin Armitage <quentin@armitage.org.uk>
 *
 *              This program is distributed in the hope that it will be useful,
 *              but WITHOUT ANY WARRANTY; without even the implied warranty of
 *              MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *              See the GNU General Public License for more details.
 *
 *              This program is free software; you can redistribute it and/or
 *              modify it under the terms of the GNU General Public License
 *              as published by the Free Software Foundation; either version
 *              2 of the License, or (at your option) any later version.
 *
 * Copyright (C) 2023 Quentin Armitage <quentin@armitage.org.uk>
 * Copyright (C) 2023-2023 Alexandre Cassen <acassen@gmail.com>
 */

#ifndef _GLOBAL_JSON_H
#define _GLOBAL_JSON_H

/* https://jsonlint.com/ is useful to check validity of JSON output */

#define JSON_VERSION_V1	1
#define JSON_VERSION_V2	2

#endif
